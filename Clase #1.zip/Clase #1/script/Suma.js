export const Suma = (num1,num2) =>{
    let suma =  num1 + num2
    return suma
}