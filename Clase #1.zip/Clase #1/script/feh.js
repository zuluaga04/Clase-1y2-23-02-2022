export const Fahrenheit = (F) =>{
let Cel = (F-32)*(5/9)
return Cel 
}