export const Resta = (num1,num2) =>{
    let resta =  num1 - num2
    return resta
}