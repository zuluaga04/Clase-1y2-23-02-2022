export const Multiplicacion = (num1,num2) =>{
    let multiplicacion =  num1 * num2
    return multiplicacion
}