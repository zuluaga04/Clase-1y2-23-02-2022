export const Division = (num1,num2) =>{
    let division =  num1 / num2
    return division
}